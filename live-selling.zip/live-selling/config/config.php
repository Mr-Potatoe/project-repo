<?php
// Automatically detect the server URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost'; // Get the host (e.g., ngrok or localhost)
$scriptName = dirname($_SERVER['SCRIPT_NAME']); // Get the directory of the script

// Construct the base URL dynamically
$base_url = rtrim($protocol . $host . $scriptName, '/');

// Define constants for global use
define('BASE_URL', $base_url);
define('SITE_NAME', 'Live Selling');

session_start();
?>
