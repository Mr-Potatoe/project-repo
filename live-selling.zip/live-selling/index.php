<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/header.php';


$db = Database::getInstance()->getConnection();

// Fetch active live streams
$liveStreamsQuery = "
    SELECT ls.*, u.username as seller_name, sp.shop_name 
    FROM live_streams ls
    JOIN users u ON ls.seller_id = u.user_id
    JOIN seller_profiles sp ON ls.seller_id = sp.seller_id
    WHERE ls.status = 'live'
    ORDER BY ls.actual_start DESC
    LIMIT 6
";

// Fetch featured products
$productsQuery = "
    SELECT p.*, u.username as seller_name
    FROM products p
    JOIN users u ON p.seller_id = u.user_id
    WHERE p.status = 'available'
    ORDER BY p.created_at DESC
    LIMIT 8
";

try {
    $liveStreams = $db->query($liveStreamsQuery)->fetchAll(PDO::FETCH_ASSOC);
    $products = $db->query($productsQuery)->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Error loading content: " . $e->getMessage();
}
?>

<div class="container mt-4">
    <?php if(isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Welcome Section -->
    <div class="jumbotron bg-light p-5 rounded mb-4">
        <h1 class="display-4">Welcome to <?= SITE_NAME ?></h1>
        <p class="lead">Discover live shopping experiences and amazing deals!</p>
        <?php if(!isset($_SESSION['user_id'])): ?>
            <a href="register.php" class="btn btn-primary">Join Now</a>
        <?php elseif($_SESSION['user_type'] === 'seller'): ?>
            <a href="stream/create.php" class="btn btn-primary">Start Streaming</a>
        <?php endif; ?>
    </div>

    <!-- Live Streams Section -->
    <h2 class="mb-4">Live Now</h2>
    <div class="row g-4 mb-5">
        <?php if(empty($liveStreams)): ?>
            <div class="col-12">
                <div class="alert alert-info">No live streams at the moment.</div>
            </div>
        <?php else: ?>
            <?php foreach($liveStreams as $stream): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="badge bg-danger">LIVE</span>
                                <small class="text-muted">
                                    <i class="bi bi-person-fill"></i> 
                                    <?= $stream['viewer_count'] ?> watching
                                </small>
                            </div>
                            <h5 class="card-title"><?= htmlspecialchars($stream['title']) ?></h5>
                            <p class="card-text">
                                <small class="text-muted">
                                    By <?= htmlspecialchars($stream['shop_name']) ?>
                                </small>
                            </p>
                            <a href="stream/view.php?id=<?= $stream['stream_id'] ?>" 
                               class="btn btn-primary stretched-link">
                                Watch Now
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Featured Products Section -->
    <h2 class="mb-4">Featured Products</h2>
    <div class="row g-4 mb-5">
        <?php if(empty($products)): ?>
            <div class="col-12">
                <div class="alert alert-info">No products available.</div>
            </div>
        <?php else: ?>
            <?php foreach($products as $product): ?>
                <div class="col-md-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                            <p class="card-text">
                                <strong>₱<?= number_format($product['price'], 2) ?></strong>
                            </p>
                            <p class="card-text">
                                <small class="text-muted">Sold by: <?= htmlspecialchars($product['seller_name']) ?></small>
                            </p>
                            <?php if(isset($_SESSION['user_id']) && $_SESSION['user_type'] === 'buyer'): ?>
                                <div class="d-flex align-items-center">
                                    <input type="number" class="form-control form-control-sm me-2 reserve-quantity" 
                                           min="1" max="<?= $product['quantity'] ?>" value="1" 
                                           style="width: 70px;"
                                           data-max="<?= $product['quantity'] ?>">
                                    <button class="btn btn-outline-primary btn-sm reserve-product" 
                                            data-product-id="<?= $product['product_id'] ?>">
                                        Reserve
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Call to Action Section -->
    <?php if(isset($_SESSION['user_id']) && $_SESSION['user_type'] === 'buyer'): ?>
        <div class="text-center p-5 bg-light rounded">
            <h3>Want to start selling?</h3>
            <p>Upgrade your account to become a seller and start your live selling journey!</p>
            <a href="upgrade.php" class="btn btn-success">Become a Seller</a>
        </div>
    <?php endif; ?>
</div>

<!-- Add Bootstrap JS and custom scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle product reservation
    const reserveButtons = document.querySelectorAll('.reserve-product');
    reserveButtons.forEach(button => {
        button.addEventListener('click', async function(e) {
            e.preventDefault();
            const productId = this.dataset.productId;
            const quantityInput = this.parentElement.querySelector('.reserve-quantity');
            const quantity = parseInt(quantityInput.value);
            const maxQuantity = parseInt(quantityInput.dataset.max);
            
            if (quantity < 1 || quantity > maxQuantity) {
                alert(`Please select a quantity between 1 and ${maxQuantity}`);
                return;
            }
            
            try {
                const response = await fetch('<?= BASE_URL ?>/api/reserve-product.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        product_id: productId,
                        quantity: quantity
                    }),
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.success) {
                    this.textContent = 'Reserved';
                    this.disabled = true;
                    this.classList.remove('btn-primary');
                    this.classList.add('btn-success');
                    quantityInput.disabled = true;
                } else {
                    alert(data.message || 'Failed to reserve product');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Failed to reserve product. Please try again.');
            }
        });
    });
});
</script> 