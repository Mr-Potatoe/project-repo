<?php
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <meta name="permissions-policy" content="camera=*, microphone=*">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom mb-4">
    <div class="container">
        <span class="navbar-brand">Seller Dashboard</span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sellerNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="sellerNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>/seller/dashboard.php">Overview</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>/seller/products.php">Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>/seller/streams.php">Live Streams</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>/seller/orders.php">Orders</a>
                </li>
            </ul>
            
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="quickActions" role="button" 
                       data-bs-toggle="dropdown" aria-expanded="false">
                        Quick Actions
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="quickActions">
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/seller/create-product.php">Add Product</a></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/seller/create-stream.php">Start Stream</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/seller/profile.php">Shop Settings</a></li>
                        <!-- logout -->
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Add Bootstrap JS at the bottom -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>