<?php
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use React\EventLoop\Factory;
use React\Socket\SecureServer;
use React\Socket\Server;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class StreamWebSocket implements MessageComponentInterface {
    protected $clients;
    protected $streams;
    
    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->streams = [];
    }
    
    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";
    }
    
    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg);
        
        switch($data->type) {
            case 'init':
                $this->streams[$data->streamId] = [
                    'broadcaster' => $from,
                    'viewers' => []
                ];
                break;
                
            case 'chat':
                foreach ($this->streams[$data->streamId]['viewers'] as $viewer) {
                    $viewer->send(json_encode([
                        'type' => 'chat',
                        'message' => $data->message,
                        'username' => $data->username
                    ]));
                }
                break;
        }
    }
    
    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }
    
    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }
}

$loop = Factory::create();
$webSocket = new StreamWebSocket();

// Create your secure WebSocket server
$secureWebsocketServer = new Server('0.0.0.0:8080', $loop);
$secureWebsocketServer = new SecureServer($secureWebsocketServer, $loop, [
    'local_cert' => __DIR__ . '/../ssl/cert.pem',    // Path to your SSL certificate
    'local_pk' => __DIR__ . '/../ssl/key.pem',       // Path to your SSL private key
    'verify_peer' => false
]);

$server = new IoServer(
    new HttpServer(
        new WsServer(
            $webSocket
        )
    ),
    $secureWebsocketServer,
    $loop
);

echo "Secure WebSocket server started on port 8080\n";
$loop->run(); 