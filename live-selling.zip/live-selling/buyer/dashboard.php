<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../models/Buyer.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    header('Location: ../login.php');
    exit;
}

$buyer = new Buyer();
$reservations = $buyer->getMyReservations($_SESSION['user_id']);
?>

<div class="container mt-4">
    <h2>My Dashboard</h2>
    
    <!-- My Reservations -->
    <div class="card mt-4">
        <div class="card-header">
            My Reservations
        </div>
        <div class="card-body">
            <?php if (empty($reservations)): ?>
                <p class="text-muted">No reservations yet.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Seller</th>
                                <th>Reserved Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reservations as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['name']) ?></td>
                                    <td>₱<?= number_format($item['price'], 2) ?></td>
                                    <td><?= htmlspecialchars($item['seller_name']) ?></td>
                                    <td><?= date('M d, Y', strtotime($item['created_at'])) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary contact-seller" 
                                                data-seller-id="<?= $item['seller_id'] ?>">
                                            Contact Seller
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const contactButtons = document.querySelectorAll('.contact-seller');
    contactButtons.forEach(button => {
        button.addEventListener('click', function() {
            const sellerId = this.dataset.sellerId;
            window.location.href = `../messages.php?user=${sellerId}`;
        });
    });
});
</script> 