<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../models/Buyer.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$buyer = new Buyer();
$watchHistory = $buyer->getWatchHistory($_SESSION['user_id']);
$favorites = $buyer->getFavorites($_SESSION['user_id']);
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Profile Information</h5>
                    <p class="card-text">Username: <?= htmlspecialchars($_SESSION['username']) ?></p>
                    <a href="edit-profile.php" class="btn btn-primary">Edit Profile</a>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">Watch History</div>
                <div class="card-body">
                    <?php if (empty($watchHistory)): ?>
                        <p class="text-muted">No watch history yet.</p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($watchHistory as $stream): ?>
                                <a href="<?= BASE_URL ?>/stream/view.php?id=<?= $stream['stream_id'] ?>" 
                                   class="list-group-item list-group-item-action">
                                    <h6><?= htmlspecialchars($stream['title']) ?></h6>
                                    <small class="text-muted">
                                        by <?= htmlspecialchars($stream['shop_name']) ?> • 
                                        <?= date('M d, Y', strtotime($stream['actual_start'])) ?>
                                    </small>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?= BASE_URL ?>/js/buyer.js"></script> 