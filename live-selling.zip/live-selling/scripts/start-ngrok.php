<?php
require __DIR__ . '/../vendor/autoload.php';

use Symfony\Component\Process\Process;

// Start HTTP tunnel
$httpProcess = new Process(['ngrok', 'http', '80']);
$httpProcess->start();

// Start WebSocket tunnel
$wsProcess = new Process(['ngrok', 'tcp', '8080']);
$wsProcess->start();

echo "Starting ngrok tunnels...\n";

while ($httpProcess->isRunning() && $wsProcess->isRunning()) {
    echo $httpProcess->getIncrementalOutput();
    echo $wsProcess->getIncrementalOutput();
    sleep(1);
}

if (!$httpProcess->isSuccessful() || !$wsProcess->isSuccessful()) {
    echo "Error starting ngrok tunnels\n";
    exit(1);
} 