<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Ensure user is logged in and is a buyer
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = Database::getInstance()->getConnection();
    
    $shop_name = filter_input(INPUT_POST, 'shop_name', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
    
    try {
        $db->beginTransaction();
        
        // Update user type to seller
        $updateUser = $db->prepare("
            UPDATE users 
            SET user_type = 'seller' 
            WHERE user_id = ?
        ");
        $updateUser->execute([$_SESSION['user_id']]);
        
        // Create seller profile
        $createProfile = $db->prepare("
            INSERT INTO seller_profiles (seller_id, shop_name, description, rating) 
            VALUES (?, ?, ?, 0.00)
        ");
        $createProfile->execute([$_SESSION['user_id'], $shop_name, $description]);
        
        $db->commit();
        
        // Update session
        $_SESSION['user_type'] = 'seller';
        
        header('Location: ' . BASE_URL . '/seller/dashboard.php');
        exit;
        
    } catch(PDOException $e) {
        $db->rollBack();
        $error = "Upgrade failed. Please try again.";
    }
}
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Upgrade to Seller Account</h4>
                </div>
                <div class="card-body">
                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    
                    <div class="alert alert-info">
                        <h5>Benefits of becoming a seller:</h5>
                        <ul class="mb-0">
                            <li>Create your own online shop</li>
                            <li>Host live selling sessions</li>
                            <li>Manage your products and inventory</li>
                            <li>Connect with buyers directly</li>
                        </ul>
                    </div>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label>Shop Name</label>
                            <input type="text" name="shop_name" class="form-control" required
                                   placeholder="Enter your shop name">
                            <small class="text-muted">This will be displayed to buyers</small>
                        </div>
                        
                        <div class="mb-3">
                            <label>Shop Description</label>
                            <textarea name="description" class="form-control" rows="4" required
                                    placeholder="Tell buyers about your shop and what you sell"></textarea>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input type="checkbox" class="form-check-input" required id="terms">
                            <label class="form-check-label" for="terms">
                                I agree to the seller terms and conditions
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Upgrade to Seller Account</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    form.addEventListener('submit', function(e) {
        const shopName = form.querySelector('input[name="shop_name"]').value.trim();
        if (shopName.length < 3) {
            e.preventDefault();
            alert('Shop name must be at least 3 characters long');
        }
    });
});
</script> 