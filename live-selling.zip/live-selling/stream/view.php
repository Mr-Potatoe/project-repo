<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../models/Stream.php';

$streamId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$streamId) {
    header('Location: ' . BASE_URL);
    exit;
}

$stream = new Stream();
$streamData = $stream->getStreamDetails($streamId);

if (!$streamData || $streamData['status'] !== 'live') {
    header('Location: ' . BASE_URL);
    exit;
}
?>
<div class="container-fluid mt-4">
    <div class="row">
        <!-- Stream View -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-body p-0">
                    <div id="stream-container" class="bg-dark" style="height: 75vh;">
                        <video id="remote-video" autoplay playsinline class="w-100 h-100"></video>
                    </div>
                    <div class="p-3">
                        <h4><?= htmlspecialchars($streamData['title']) ?></h4>
                        <div class="d-flex align-items-center">
                            <img src="<?= BASE_URL ?>/<?= $streamData['profile_picture'] ?? 'assets/images/default-profile.png' ?>" 
                                 class="rounded-circle me-2" style="width: 40px; height: 40px;">
                            <div>
                                <h6 class="mb-0"><?= htmlspecialchars($streamData['shop_name']) ?></h6>
                                <small class="text-muted">
                                    <span id="viewer-count">0</span> watching
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Chat and Products -->
        <div class="col-md-4">
            <!-- Live Chat -->
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0">Live Chat</h5>
                </div>
                <div class="card-body p-0">
                    <div id="chat-messages" class="p-3" style="height: 300px; overflow-y: auto;"></div>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <form id="chat-form" class="p-3 border-top">
                            <div class="input-group">
                                <input type="text" id="chat-input" class="form-control" 
                                       placeholder="Type a message...">
                                <button type="submit" class="btn btn-primary">Send</button>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="p-3 border-top text-center">
                            <a href="<?= BASE_URL ?>/login.php" class="btn btn-outline-primary">
                                Login to Chat
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Featured Products -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Featured Products</h5>
                </div>
                <div class="card-body" id="featured-products">
                    <!-- Products will be loaded here -->
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/simple-peer@9.11.1/simplepeer.min.js"></script>
<script>
const streamId = <?= $streamId ?>;
const userId = <?= isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'null' ?>;
const username = <?= isset($_SESSION['username']) ? json_encode($_SESSION['username']) : 'null' ?>;
const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
const wsHost = window.location.hostname;
const wsUrl = `${wsProtocol}//${wsHost}:8080`;
let ws;
let peer;

// Initialize WebSocket connection
function initWebSocket() {
    ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
        console.log('Connected to WebSocket server');
        // Register as viewer
        ws.send(JSON.stringify({
            type: 'viewer',
            streamId: streamId
        }));
    };

    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        console.log('Received:', data);

        switch (data.type) {
            case 'chat':
                addChatMessage(data.username, data.message);
                break;

            case 'viewer_count':
                updateViewerCount(data.count);
                break;

            case 'signal':
                handleSignal(data);
                break;

            case 'stream_ended':
                if (peer) {
                    peer.destroy();
                    peer = null;
                }
                alert('Stream has ended');
                window.location.href = BASE_URL;
                break;

            case 'ping':
                ws.send(JSON.stringify({ type: 'pong' }));
                break;
        }
    };

    ws.onclose = () => {
        console.log('Disconnected from WebSocket server');
        setTimeout(initWebSocket, 5000); // Reconnect after 5 seconds
    };

    ws.onerror = (error) => {
        console.error('WebSocket error:', error);
    };
}

function handleSignal(data) {
    if (!peer) {
        // Create peer when receiving first signal
        peer = new SimplePeer({
            initiator: false,
            trickle: false,
            config: {
                iceServers: [
                    { urls: 'stun:stun.l.google.com:19302' },
                    { urls: 'stun:stun.relay.metered.ca:80' },
                    { urls: 'stun:global.stun.twilio.com:3478' }
                ]
            }
        });
        
        peer.on('signal', signal => {
            ws.send(JSON.stringify({
                type: 'signal',
                signal: signal
            }));
        });
        
        peer.on('stream', stream => {
            handleStream(stream);
        });
        
        peer.on('error', err => {
            console.error('Peer error:', err);
            if (peer) {
                peer.destroy();
                peer = null;
            }
            setTimeout(initWebSocket, 1000);
        });

        peer.on('close', () => {
            console.log('Peer connection closed');
            setTimeout(initWebSocket, 1000);
        });
    }
    
    try {
        peer.signal(data.signal);
    } catch (err) {
        console.error('Error processing signal:', err);
        if (peer) {
            peer.destroy();
            peer = null;
        }
        setTimeout(initWebSocket, 1000);
    }
}

function handleStream(stream) {
    const video = document.getElementById('remote-video');
    if (!video) {
        console.error('Video element not found');
        return;
    }

    try {
        // Create audio context and processing chain
        const audioContext = new AudioContext();
        const source = audioContext.createMediaStreamSource(stream);
        const gainNode = audioContext.createGain();
        const analyser = audioContext.createAnalyser();
        analyser.fftSize = 2048;

        // Connect audio nodes
        source.connect(gainNode);
        gainNode.connect(analyser);
        gainNode.connect(audioContext.destination);

        // Set initial volume
        gainNode.gain.value = 1.0;

        // Create audio controls
        const audioControls = document.createElement('div');
        audioControls.className = 'audio-controls mt-2';
        audioControls.innerHTML = `
            <div class="d-flex align-items-center">
                <button id="toggle-audio" class="btn btn-primary me-2">
                    <i class="fas fa-volume-up"></i>
                </button>
                <input type="range" id="volume-slider" class="form-range" 
                       min="0" max="100" value="100" style="width: 150px;">
                <div id="audio-meter" class="ms-2" style="width: 20px; height: 20px; border-radius: 50%;"></div>
            </div>
        `;
        video.parentElement.appendChild(audioControls);

        // Audio controls functionality
        const volumeSlider = document.getElementById('volume-slider');
        const toggleAudio = document.getElementById('toggle-audio');
        const audioMeter = document.getElementById('audio-meter');
        let isMuted = false;

        volumeSlider.addEventListener('input', (e) => {
            const volume = e.target.value / 100;
            gainNode.gain.value = volume;
            video.volume = volume;
        });

        toggleAudio.addEventListener('click', () => {
            isMuted = !isMuted;
            video.muted = isMuted;
            gainNode.gain.value = isMuted ? 0 : volumeSlider.value / 100;
            toggleAudio.innerHTML = isMuted ? 
                '<i class="fas fa-volume-mute"></i>' : 
                '<i class="fas fa-volume-up"></i>';
        });

        // Audio level monitoring
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        function updateAudioMeter() {
            analyser.getByteFrequencyData(dataArray);
            const audioLevel = dataArray.reduce((a, b) => a + b) / dataArray.length;
            
            // Update audio meter visual
            const intensity = Math.min(audioLevel / 128, 1);
            audioMeter.style.backgroundColor = `rgba(0, 255, 0, ${intensity})`;
            
            // Log audio levels and warnings
            console.log('Receiving audio level:', audioLevel);
            if (audioLevel < 1) {
                console.warn('No audio detected from broadcaster');
                audioMeter.style.backgroundColor = 'red';
            }
            
            requestAnimationFrame(updateAudioMeter);
        }
        updateAudioMeter();

        // Set up video element
        video.srcObject = stream;
        video.playsInline = true;
        video.muted = false;
        video.volume = 1.0;
        video.controls = true;

        // Handle autoplay
        video.play().catch(error => {
            console.error('Error playing stream:', error);
            if (error.name === 'NotAllowedError') {
                const playButton = document.createElement('button');
                playButton.className = 'btn btn-primary position-absolute top-50 start-50 translate-middle';
                playButton.innerHTML = '<i class="fas fa-play"></i> Click to Play';
                playButton.onclick = () => {
                    // Resume audio context if suspended
                    if (audioContext.state === 'suspended') {
                        audioContext.resume();
                    }
                    video.play().then(() => {
                        video.muted = false;
                        playButton.remove();
                    }).catch(console.error);
                };
                video.parentElement.appendChild(playButton);
            }
        });

        // Monitor audio tracks
        stream.getAudioTracks().forEach(track => {
            console.log('Audio track:', track.label, 'enabled:', track.enabled);
            track.onended = () => console.log('Audio track ended:', track.label);
            track.onmute = () => console.log('Audio track muted:', track.label);
            track.onunmute = () => console.log('Audio track unmuted:', track.label);
        });

        // Monitor connection quality
        if (peer && peer._pc) {
            setInterval(() => {
                peer._pc.getStats().then(stats => {
                    stats.forEach(report => {
                        if (report.type === 'inbound-rtp' && report.kind === 'audio') {
                            console.log('Audio stats:', {
                                bytesReceived: report.bytesReceived,
                                packetsReceived: report.packetsReceived,
                                packetsLost: report.packetsLost,
                                jitter: report.jitter
                            });
                        }
                    });
                }).catch(console.error);
            }, 3000);
        }
    } catch (error) {
        console.error('Error setting up audio:', error);
    }
}

// Chat functionality
function addChatMessage(username, message) {
    const chatMessages = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'mb-2';
    messageDiv.innerHTML = `
        <strong>${escapeHtml(username)}:</strong>
        <span>${escapeHtml(message)}</span>
    `;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Handle chat form submission
document.getElementById('chat-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (message && ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'chat',
            streamId: streamId,
            message: message,
            userId: userId,
            username: username
        }));
        input.value = '';
    }
});

function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function updateViewerCount(count) {
    document.getElementById('viewer-count').textContent = count;
}

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    const video = document.getElementById('remote-video');
    if (document.hidden) {
        video.pause();
    } else {
        video.play().catch(console.error);
    }
});

// Initialize everything when the page loads
document.addEventListener('DOMContentLoaded', function() {
    initWebSocket();
});
</script> 