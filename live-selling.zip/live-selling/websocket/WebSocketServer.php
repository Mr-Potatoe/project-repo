<?php
require dirname(__DIR__) . '/vendor/autoload.php';
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class WebSocketServer implements MessageComponentInterface {
    protected $clients;
    protected $streams = [];
    protected $broadcasters = [];
    protected $viewers = [];
    protected $pingInterval = 30; // Ping every 30 seconds
    protected $lastPing = [];
    protected $logger;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->initLogger();
        $this->startPingTimer();
    }

    protected function initLogger() {
        $logFile = dirname(__DIR__) . '/logs/websocket.log';
        if (!file_exists(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
        $this->logger = function($message) use ($logFile) {
            $timestamp = date('Y-m-d H:i:s');
            file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
            echo "[$timestamp] $message\n";
        };
    }

    protected function log($message) {
        call_user_func($this->logger, $message);
    }

    protected function startPingTimer() {
        // Create a timer to ping clients periodically
        $loop = \React\EventLoop\Loop::get();
        $loop->addPeriodicTimer($this->pingInterval, function () {
            $this->pingClients();
        });
    }

    protected function pingClients() {
        foreach ($this->clients as $client) {
            try {
                // Send ping frame
                $client->send(json_encode(['type' => 'ping']));
                $this->lastPing[$client->resourceId] = time();
            } catch (\Exception $e) {
                $this->log("Error pinging client {$client->resourceId}: " . $e->getMessage());
                $this->handleDisconnection($client);
            }
        }

        // Check for stale connections
        foreach ($this->lastPing as $resourceId => $lastPingTime) {
            if (time() - $lastPingTime > $this->pingInterval * 2) {
                foreach ($this->clients as $client) {
                    if ($client->resourceId == $resourceId) {
                        $this->log("Client $resourceId timed out, closing connection");
                        $this->handleDisconnection($client);
                        break;
                    }
                }
            }
        }
    }

    protected function handleDisconnection($conn) {
        try {
            // Clean up broadcaster if this was one
            foreach ($this->broadcasters as $streamId => $broadcaster) {
                if ($broadcaster === $conn) {
                    $this->log("Broadcaster disconnected from stream $streamId");
                    $this->broadcastToStream($streamId, json_encode([
                        'type' => 'stream_ended'
                    ]));
                    unset($this->broadcasters[$streamId]);
                    unset($this->streams[$streamId]);
                    break;
                }
            }

            // Clean up viewer if this was one
            if (isset($this->viewers[$conn->resourceId])) {
                $streamId = $this->viewers[$conn->resourceId]['stream_id'];
                if (isset($this->streams[$streamId])) {
                    $this->streams[$streamId]->detach($conn);
                    
                    // Update viewer count
                    $viewerCount = $this->streams[$streamId]->count();
                    $this->broadcastToStream($streamId, json_encode([
                        'type' => 'viewer_count',
                        'count' => $viewerCount
                    ]));
                    
                    // Notify broadcaster about viewer disconnect
                    if (isset($this->broadcasters[$streamId])) {
                        $this->broadcasters[$streamId]->send(json_encode([
                            'type' => 'viewer_disconnected',
                            'viewerId' => $conn->resourceId,
                            'viewerCount' => $viewerCount
                        ]));
                    }
                }
                unset($this->viewers[$conn->resourceId]);
            }

            // Clean up from clients list
            $this->clients->detach($conn);
            unset($this->lastPing[$conn->resourceId]);
        } catch (\Exception $e) {
            $this->log("Error in handleDisconnection: " . $e->getMessage());
        }
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        $this->lastPing[$conn->resourceId] = time();
        $this->log("New connection! ({$conn->resourceId})");
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg);
        
        if (!$data) {
            $this->log("Received invalid JSON message");
            return;
        }

        switch ($data->type) {
            case 'broadcaster':
                $this->handleBroadcaster($from, $data);
                break;

            case 'viewer':
                $this->handleViewer($from, $data);
                break;

            case 'signal':
                $this->handleSignal($from, $data);
                break;

            case 'chat':
                $this->handleChat($from, $data);
                break;

            case 'pong':
                $this->lastPing[$from->resourceId] = time();
                break;
        }
    }

    protected function handleChat($from, $data) {
        if (!isset($data->streamId) || !isset($data->message)) {
            return;
        }

        $streamId = $data->streamId;
        $username = isset($data->username) ? $data->username : 'Anonymous';
        $message = $data->message;

        // Create chat message
        $chatMessage = json_encode([
            'type' => 'chat',
            'username' => $username,
            'message' => $message,
            'timestamp' => time()
        ]);

        // Broadcast to everyone in the stream
        $this->broadcastToStream($streamId, $chatMessage);
    }

    protected function broadcastToStream($streamId, $message) {
        if (!isset($this->streams[$streamId])) {
            return;
        }

        // Send to broadcaster
        if (isset($this->broadcasters[$streamId])) {
            try {
                $this->broadcasters[$streamId]->send($message);
            } catch (\Exception $e) {
                $this->log("Error sending to broadcaster: " . $e->getMessage());
            }
        }

        // Send to all viewers
        foreach ($this->streams[$streamId] as $client) {
            try {
                $client->send($message);
            } catch (\Exception $e) {
                $this->log("Error sending to viewer: " . $e->getMessage());
                $this->handleDisconnection($client);
            }
        }
    }

    protected function handleBroadcaster($from, $data) {
        $streamId = $data->streamId;
        
        // Register as broadcaster
        $this->broadcasters[$streamId] = $from;
        
        // Initialize stream if not exists
        if (!isset($this->streams[$streamId])) {
            $this->streams[$streamId] = new \SplObjectStorage;
        }
        
        $this->log("Broadcaster connected for stream $streamId");
    }

    protected function handleViewer($from, $data) {
        $streamId = $data->streamId;
        
        // Initialize stream if not exists
        if (!isset($this->streams[$streamId])) {
            $this->streams[$streamId] = new \SplObjectStorage;
        }
        
        // Add to viewers
        $this->streams[$streamId]->attach($from);
        $this->viewers[$from->resourceId] = [
            'stream_id' => $streamId,
            'user_id' => isset($data->userId) ? $data->userId : null,
            'username' => isset($data->username) ? $data->username : 'Anonymous'
        ];
        
        // Update viewer count
        $viewerCount = $this->streams[$streamId]->count();
        $this->broadcastToStream($streamId, json_encode([
            'type' => 'viewer_count',
            'count' => $viewerCount
        ]));
        
        $this->log("Viewer connected to stream $streamId. Total viewers: $viewerCount");
        
        // Notify broadcaster
        if (isset($this->broadcasters[$streamId])) {
            $this->broadcasters[$streamId]->send(json_encode([
                'type' => 'viewer_connected',
                'viewerId' => $from->resourceId,
                'viewerCount' => $viewerCount
            ]));
        }
    }

    protected function handleSignal($from, $data) {
        if (isset($data->viewerId)) {
            // Signal from broadcaster to viewer
            foreach ($this->clients as $client) {
                if ($client->resourceId == $data->viewerId) {
                    $client->send(json_encode([
                        'type' => 'signal',
                        'signal' => $data->signal
                    ]));
                    break;
                }
            }
        } else {
            // Signal from viewer to broadcaster
            $viewerInfo = $this->viewers[$from->resourceId] ?? null;
            if ($viewerInfo && isset($this->broadcasters[$viewerInfo['stream_id']])) {
                $this->broadcasters[$viewerInfo['stream_id']]->send(json_encode([
                    'type' => 'signal',
                    'viewerId' => $from->resourceId,
                    'signal' => $data->signal
                ]));
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->log("Connection {$conn->resourceId} has disconnected");
        $this->handleDisconnection($conn);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $this->log("An error occurred: {$e->getMessage()}");
        $this->handleDisconnection($conn);
        $conn->close();
    }

    protected function broadcastViewerCount($streamId) {
        if (isset($this->streams[$streamId])) {
            $count = count($this->streams[$streamId]);
            $this->broadcastToStream($streamId, json_encode([
                'type' => 'viewer_count',
                'count' => $count
            ]));
        }
    }
}

// Configure the server with a longer timeout
$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new WebSocketServer()
        )
    ),
    8080,
    '0.0.0.0',
    [
        'backlog' => 200,
        'timeout' => 60
    ]
);

echo "WebSocket Server Started on port 8080\n";
$server->run();
