document.addEventListener('DOMContentLoaded', function() {
    // Handle favorite toggling
    const favButtons = document.querySelectorAll('.toggle-favorite');
    favButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            fetch('../api/toggle-favorite.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ product_id: productId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.classList.toggle('active');
                }
            });
        });
    });
}); 