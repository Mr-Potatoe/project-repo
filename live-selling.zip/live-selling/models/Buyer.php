<?php
class Buyer {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function getMyReservations($userId) {
        $stmt = $this->db->prepare("
            SELECT p.*, u.username as seller_name, sp.shop_name
            FROM products p
            JOIN users u ON p.seller_id = u.user_id
            JOIN seller_profiles sp ON u.user_id = sp.seller_id
            WHERE p.status = 'reserved'
            ORDER BY p.created_at DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getWatchHistory($userId) {
        $stmt = $this->db->prepare("
            SELECT ls.*, u.username as seller_name, sp.shop_name
            FROM stream_viewers sv
            JOIN live_streams ls ON sv.stream_id = ls.stream_id
            JOIN users u ON ls.seller_id = u.user_id
            JOIN seller_profiles sp ON u.user_id = sp.seller_id
            WHERE sv.user_id = ?
            ORDER BY sv.joined_at DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getFavorites($userId) {
        $stmt = $this->db->prepare("
            SELECT p.*, u.username as seller_name
            FROM favorites f
            JOIN products p ON f.product_id = p.product_id
            JOIN users u ON p.seller_id = u.user_id
            WHERE f.user_id = ?
            ORDER BY f.created_at DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getConversations($userId) {
        $stmt = $this->db->prepare("
            SELECT DISTINCT 
                u.user_id as seller_id,
                sp.shop_name,
                (SELECT content 
                 FROM private_messages 
                 WHERE (sender_id = ? AND receiver_id = u.user_id) 
                    OR (sender_id = u.user_id AND receiver_id = ?)
                 ORDER BY created_at DESC 
                 LIMIT 1) as last_message,
                (SELECT COUNT(*) 
                 FROM private_messages 
                 WHERE sender_id = u.user_id 
                    AND receiver_id = ? 
                    AND is_read = 0) as unread_count
            FROM private_messages pm
            JOIN users u ON (pm.sender_id = u.user_id OR pm.receiver_id = u.user_id)
            JOIN seller_profiles sp ON u.user_id = sp.seller_id
            WHERE (pm.sender_id = ? OR pm.receiver_id = ?)
                AND u.user_id != ?
            GROUP BY u.user_id
            ORDER BY MAX(pm.created_at) DESC
        ");
        $stmt->execute([$userId, $userId, $userId, $userId, $userId, $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getMessages($buyerId, $sellerId) {
        $stmt = $this->db->prepare("
            SELECT * FROM private_messages 
            WHERE (sender_id = ? AND receiver_id = ?)
               OR (sender_id = ? AND receiver_id = ?)
            ORDER BY created_at ASC
        ");
        $stmt->execute([$buyerId, $sellerId, $sellerId, $buyerId]);
        
        // Mark messages as read
        $updateStmt = $this->db->prepare("
            UPDATE private_messages 
            SET is_read = 1 
            WHERE sender_id = ? AND receiver_id = ? AND is_read = 0
        ");
        $updateStmt->execute([$sellerId, $buyerId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getSellerInfo($sellerId) {
        $stmt = $this->db->prepare("
            SELECT u.*, sp.shop_name 
            FROM users u 
            JOIN seller_profiles sp ON u.user_id = sp.seller_id
            WHERE u.user_id = ? AND u.user_type = 'seller'
        ");
        $stmt->execute([$sellerId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
} 