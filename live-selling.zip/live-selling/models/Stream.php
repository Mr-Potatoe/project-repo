<?php
class Stream {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function getStreamDetails($streamId) {
        $stmt = $this->db->prepare("
            SELECT ls.*, u.username as seller_username, 
                   sp.shop_name, sp.description as shop_description,
                   u.profile_picture
            FROM live_streams ls
            JOIN users u ON ls.seller_id = u.user_id
            JOIN seller_profiles sp ON ls.seller_id = sp.seller_id
            WHERE ls.stream_id = ?
        ");
        $stmt->execute([$streamId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function updateViewerCount($streamId, $count) {
        $stmt = $this->db->prepare("
            UPDATE live_streams 
            SET viewer_count = ? 
            WHERE stream_id = ?
        ");
        return $stmt->execute([$count, $streamId]);
    }
    
    public function getFeaturedProducts($streamId) {
        $stmt = $this->db->prepare("
            SELECT * FROM products 
            WHERE stream_id = ? AND status = 'available'
            ORDER BY created_at DESC
        ");
        $stmt->execute([$streamId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function trackViewer($streamId, $userId) {
        $stmt = $this->db->prepare("
            INSERT INTO stream_viewers (stream_id, user_id)
            VALUES (?, ?)
        ");
        return $stmt->execute([$streamId, $userId]);
    }
    
    public function updateViewerLeftTime($streamId, $userId) {
        $stmt = $this->db->prepare("
            UPDATE stream_viewers 
            SET left_at = CURRENT_TIMESTAMP
            WHERE stream_id = ? AND user_id = ? AND left_at IS NULL
        ");
        return $stmt->execute([$streamId, $userId]);
    }
    
    public function getActiveStreams($limit = 10) {
        $stmt = $this->db->prepare("
            SELECT ls.*, u.username as seller_username, 
                   sp.shop_name, u.profile_picture,
                   COUNT(DISTINCT sv.user_id) as current_viewers
            FROM live_streams ls
            JOIN users u ON ls.seller_id = u.user_id
            JOIN seller_profiles sp ON ls.seller_id = sp.seller_id
            LEFT JOIN stream_viewers sv ON ls.stream_id = sv.stream_id AND sv.left_at IS NULL
            WHERE ls.status = 'live'
            GROUP BY ls.stream_id
            ORDER BY ls.actual_start DESC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getStreamComments($streamId, $limit = 100) {
        $stmt = $this->db->prepare("
            SELECT c.*, u.username, u.profile_picture
            FROM comments c
            JOIN users u ON c.user_id = u.user_id
            WHERE c.stream_id = ?
            ORDER BY c.created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$streamId, $limit]);
        return array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    
    public function addComment($streamId, $userId, $content) {
        $stmt = $this->db->prepare("
            INSERT INTO comments (stream_id, user_id, content)
            VALUES (?, ?, ?)
        ");
        return $stmt->execute([$streamId, $userId, $content]);
    }
    
    public function endStream($streamId, $sellerId) {
        $stmt = $this->db->prepare("
            UPDATE live_streams 
            SET status = 'ended', 
                ended_at = CURRENT_TIMESTAMP
            WHERE stream_id = ? AND seller_id = ?
        ");
        
        if ($stmt->execute([$streamId, $sellerId])) {
            // Update all active viewers' left_at time
            $this->db->prepare("
                UPDATE stream_viewers 
                SET left_at = CURRENT_TIMESTAMP
                WHERE stream_id = ? AND left_at IS NULL
            ")->execute([$streamId]);
            return true;
        }
        return false;
    }
} 