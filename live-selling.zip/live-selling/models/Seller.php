<?php
class Seller {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function getProfile($sellerId) {
        $stmt = $this->db->prepare("
            SELECT u.*, sp.*
            FROM users u
            JOIN seller_profiles sp ON u.user_id = sp.seller_id
            WHERE u.user_id = ? AND u.user_type = 'seller'
        ");
        $stmt->execute([$sellerId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getProducts($sellerId) {
        $stmt = $this->db->prepare("
            SELECT * FROM products 
            WHERE seller_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->execute([$sellerId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function createProduct($data) {
        $stmt = $this->db->prepare("
            INSERT INTO products (seller_id, name, description, price, quantity)
            VALUES (?, ?, ?, ?, ?)
        ");
        return $stmt->execute([
            $data['seller_id'],
            $data['name'],
            $data['description'],
            $data['price'],
            $data['quantity']
        ]);
    }
    
    public function getLiveStreams($sellerId) {
        $stmt = $this->db->prepare("
            SELECT ls.*, 
                   COUNT(sv.user_id) as current_viewers
            FROM live_streams ls
            LEFT JOIN stream_viewers sv ON ls.stream_id = sv.stream_id
            WHERE ls.seller_id = ?
            GROUP BY ls.stream_id
            ORDER BY ls.scheduled_start DESC
        ");
        $stmt->execute([$sellerId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function createStream($data) {
        $stmt = $this->db->prepare("
            INSERT INTO live_streams (seller_id, title, description, status, scheduled_start)
            VALUES (?, ?, ?, 'scheduled', ?)
        ");
        return $stmt->execute([
            $data['seller_id'],
            $data['title'],
            $data['description'],
            $data['scheduled_start']
        ]);
    }
    
    public function updateProfile($data) {
        $stmt = $this->db->prepare("
            UPDATE seller_profiles 
            SET shop_name = ?, description = ?
            WHERE seller_id = ?
        ");
        return $stmt->execute([
            $data['shop_name'],
            $data['description'],
            $data['seller_id']
        ]);
    }
    
    public function deleteProduct($productId) {
        $stmt = $this->db->prepare("
            DELETE FROM products 
            WHERE product_id = ? AND seller_id = ?
        ");
        return $stmt->execute([$productId, $_SESSION['user_id']]);
    }
    
    public function updateProduct($data) {
        $stmt = $this->db->prepare("
            UPDATE products 
            SET name = ?, description = ?, price = ?, quantity = ?, status = ?
            WHERE product_id = ? AND seller_id = ?
        ");
        return $stmt->execute([
            $data['name'],
            $data['description'],
            $data['price'],
            $data['quantity'],
            $data['status'],
            $data['product_id'],
            $_SESSION['user_id']
        ]);
    }
    
    public function getProduct($productId) {
        $stmt = $this->db->prepare("
            SELECT * FROM products 
            WHERE product_id = ? AND seller_id = ?
        ");
        $stmt->execute([$productId, $_SESSION['user_id']]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getStream($streamId) {
        $stmt = $this->db->prepare("
            SELECT * FROM live_streams 
            WHERE stream_id = ? AND seller_id = ?
        ");
        $stmt->execute([$streamId, $_SESSION['user_id']]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function updateStreamStatus($streamId, $status) {
        $stmt = $this->db->prepare("
            UPDATE live_streams 
            SET status = ?, 
                actual_start = CASE WHEN status = 'scheduled' AND ? = 'live' 
                                   THEN CURRENT_TIMESTAMP 
                                   ELSE actual_start END
            WHERE stream_id = ? AND seller_id = ?
        ");
        return $stmt->execute([$status, $status, $streamId, $_SESSION['user_id']]);
    }
    
    public function getOrders($sellerId) {
        $stmt = $this->db->prepare("
            SELECT o.*, u.name as customer_name,
                   GROUP_CONCAT(p.name) as product_names,
                   GROUP_CONCAT(oi.quantity) as quantities
            FROM orders o
            JOIN order_items oi ON o.order_id = oi.order_id
            JOIN products p ON oi.product_id = p.product_id
            JOIN users u ON o.user_id = u.user_id
            WHERE p.seller_id = ?
            GROUP BY o.order_id
            ORDER BY o.created_at DESC
        ");
        $stmt->execute([$sellerId]);
        
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Process orders to include items array
        foreach ($orders as &$order) {
            $order['items'] = $this->getOrderItems($order['order_id']);
        }
        
        return $orders;
    }
    
    public function getOrderItems($orderId) {
        $stmt = $this->db->prepare("
            SELECT oi.*, p.name, p.price
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = ?
        ");
        $stmt->execute([$orderId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function updateOrderStatus($orderId, $status) {
        $stmt = $this->db->prepare("
            UPDATE orders 
            SET status = ?
            WHERE order_id = ? AND EXISTS (
                SELECT 1 FROM order_items oi
                JOIN products p ON oi.product_id = p.product_id
                WHERE oi.order_id = orders.order_id
                AND p.seller_id = ?
            )
        ");
        return $stmt->execute([$status, $orderId, $_SESSION['user_id']]);
    }
    
    public function getReservations($sellerId) {
        $stmt = $this->db->prepare("
            SELECT p.*, u.username as buyer_name, u.email as buyer_email
            FROM products p
            INNER JOIN users u ON p.reserved_by = u.user_id
            WHERE p.seller_id = ? 
            AND p.status = 'reserved'
            AND u.user_type = 'buyer'
            ORDER BY p.created_at DESC
        ");
        $stmt->execute([$sellerId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} 