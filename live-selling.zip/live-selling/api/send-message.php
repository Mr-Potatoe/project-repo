<?php
require_once '../config/config.php';
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['receiver_id']) || !isset($data['content'])) {
        throw new Exception('Missing required fields');
    }

    $db = Database::getInstance()->getConnection();
    
    $stmt = $db->prepare("
        INSERT INTO private_messages (sender_id, receiver_id, content)
        VALUES (?, ?, ?)
    ");
    
    if ($stmt->execute([$_SESSION['user_id'], $data['receiver_id'], $data['content']])) {
        echo json_encode(['success' => true]);
    } else {
        throw new Exception('Failed to send message');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} 