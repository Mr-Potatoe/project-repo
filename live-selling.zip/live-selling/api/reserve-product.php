<?php
// Prevent any output before JSON response
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once '../config/config.php';
require_once '../config/database.php';

// Enable CORS for AJAX requests
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    // Check if user is logged in
    if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
        throw new Exception('Only buyers can reserve products', 403);
    }

    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['product_id']) || !isset($data['quantity'])) {
        throw new Exception('Product ID and quantity are required', 400);
    }

    $quantity = intval($data['quantity']);
    if ($quantity < 1) {
        throw new Exception('Invalid quantity', 400);
    }

    $db = Database::getInstance()->getConnection();
    
    // Start transaction
    $db->beginTransaction();
    
    // Check if product is available and get its details
    $stmt = $db->prepare("
        SELECT * FROM products 
        WHERE product_id = ? AND status = 'available' AND quantity >= ?
        FOR UPDATE
    ");
    $stmt->execute([$data['product_id'], $quantity]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        throw new Exception('Product not available in requested quantity', 404);
    }
    
    // Update product
    $newQuantity = $product['quantity'] - $quantity;
    $status = $newQuantity > 0 ? 'available' : 'reserved';
    
    $stmt = $db->prepare("
        UPDATE products 
        SET status = ?,
            quantity = ?,
            reserved_by = CASE 
                WHEN ? = 0 THEN ?
                ELSE NULL 
            END
        WHERE product_id = ? 
    ");
    
    if (!$stmt->execute([$status, $newQuantity, $newQuantity, $_SESSION['user_id'], $data['product_id']])) {
        throw new Exception('Failed to reserve product', 500);
    }

    // If this is a reservation, create a new product entry for the reserved quantity
    if ($quantity < $product['quantity']) {
        $stmt = $db->prepare("
            INSERT INTO products 
            (seller_id, stream_id, name, description, price, quantity, status, reserved_by)
            VALUES (?, ?, ?, ?, ?, ?, 'reserved', ?)
        ");
        
        if (!$stmt->execute([
            $product['seller_id'],
            $product['stream_id'],
            $product['name'],
            $product['description'],
            $product['price'],
            $quantity,
            $_SESSION['user_id']
        ])) {
            throw new Exception('Failed to create reservation record', 500);
        }
    }
    
    // Commit transaction
    $db->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Product reserved successfully'
    ]);

} catch (Exception $e) {
    // Rollback transaction if started
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    
    $code = $e->getCode() ?: 500;
    http_response_code($code);
    
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 