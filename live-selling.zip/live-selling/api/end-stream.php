<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once '../config/config.php';
require_once '../config/database.php';

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
        throw new Exception('Unauthorized access');
    }

    // Get JSON input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!isset($data['stream_id'])) {
        throw new Exception('Stream ID is required');
    }

    $db = Database::getInstance()->getConnection();
    
    // Start transaction
    $db->beginTransaction();
    
    try {
        // Verify stream belongs to seller
        $stmt = $db->prepare("
            SELECT seller_id 
            FROM live_streams 
            WHERE stream_id = ? AND status = 'live'
        ");
        $stmt->execute([$data['stream_id']]);
        $stream = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$stream || $stream['seller_id'] != $_SESSION['user_id']) {
            throw new Exception('Invalid stream or unauthorized');
        }
        
        // Update stream status
        $stmt = $db->prepare("
            UPDATE live_streams 
            SET status = 'ended',
                ended_at = CURRENT_TIMESTAMP
            WHERE stream_id = ?
        ");
        
        if (!$stmt->execute([$data['stream_id']])) {
            throw new Exception('Failed to update stream status');
        }
        
        $db->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Stream ended successfully'
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 