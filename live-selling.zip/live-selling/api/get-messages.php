<?php
require_once '../config/config.php';
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    if (!isset($_GET['user_id'])) {
        throw new Exception('User ID is required');
    }

    $db = Database::getInstance()->getConnection();
    
    $stmt = $db->prepare("
        SELECT * FROM private_messages 
        WHERE (sender_id = ? AND receiver_id = ?)
        OR (sender_id = ? AND receiver_id = ?)
        ORDER BY created_at ASC
    ");
    
    $stmt->execute([
        $_SESSION['user_id'], 
        $_GET['user_id'],
        $_GET['user_id'],
        $_SESSION['user_id']
    ]);
    
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'messages' => $messages
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} 