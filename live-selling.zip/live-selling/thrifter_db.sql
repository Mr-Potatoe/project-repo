-- Create the database
CREATE DATABASE IF NOT EXISTS live-selling;
USE live-selling;

-- Users table (base table for all user types)
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    user_type ENUM('admin', 'seller', 'buyer') NOT NULL,
    profile_picture VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Seller profiles table     
CREATE TABLE seller_profiles (
    seller_id INT PRIMARY KEY,
    shop_name VARCHAR(100) NOT NULL,
    description TEXT,
    rating DECIMAL(3,2),
    FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Live streams table
CREATE TABLE live_streams (
    stream_id INT PRIMARY KEY AUTO_INCREMENT,
    seller_id INT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status ENUM('scheduled', 'live', 'ended') NOT NULL,
    scheduled_start DATETIME,
    actual_start DATETIME,
    ended_at DATETIME,
    viewer_count INT DEFAULT 0,
    FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Products table
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    seller_id INT,
    stream_id INT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL,
    status ENUM('available', 'sold', 'reserved') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reserved_by INT NULL,
    FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (stream_id) REFERENCES live_streams(stream_id) ON DELETE SET NULL,
    FOREIGN KEY (reserved_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Comments table
CREATE TABLE comments (
    comment_id INT PRIMARY KEY AUTO_INCREMENT,
    stream_id INT,
    user_id INT,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stream_id) REFERENCES live_streams(stream_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Private messages table
CREATE TABLE private_messages (
    message_id INT PRIMARY KEY AUTO_INCREMENT,
    sender_id INT,
    receiver_id INT,
    content TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Stream viewers table (to track viewers in a live stream)
CREATE TABLE stream_viewers (
    stream_id INT,
    user_id INT,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    left_at TIMESTAMP NULL,
    PRIMARY KEY (stream_id, user_id, joined_at),
    FOREIGN KEY (stream_id) REFERENCES live_streams(stream_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, password, email, user_type) 
VALUES ('admin', '$2y$10$8FPr.YhQ3LmHYdMx/NVHi.dCxo0H59KX9jX4WrFqQk9TVaaiQdR3O', 'admin@thrifter.com', 'admin');
