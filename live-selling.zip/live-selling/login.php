<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = Database::getInstance()->getConnection();
    
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    
    $stmt = $db->prepare("SELECT user_id, username, password, user_type FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_type'] = $user['user_type'];
        
        // Redirect based on user type
        switch($user['user_type']) {
            case 'seller':
                header('Location: ' . BASE_URL . '/seller/dashboard.php');
                break;
            case 'buyer':
                header('Location: ' . BASE_URL . '/buyer/dashboard.php');
                break;
            case 'admin':
                header('Location: ' . BASE_URL . '/admin/dashboard.php');
                break;
            default:
                header('Location: ' . BASE_URL . '/index.php');
        }
        exit;
    } else {
        $error = "Invalid credentials";
    }
}
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">Login</div>
                <div class="card-body">
                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Login</button>
                        <a href="register.php" class="btn btn-link">Create Account</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> 