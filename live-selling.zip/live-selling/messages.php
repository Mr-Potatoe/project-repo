<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'models/Buyer.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$buyer = new Buyer();
$conversations = $buyer->getConversations($_SESSION['user_id']);
$currentSellerId = isset($_GET['user']) ? (int)$_GET['user'] : null;

// Get messages if a seller is selected
$messages = [];
if ($currentSellerId) {
    $messages = $buyer->getMessages($_SESSION['user_id'], $currentSellerId);
    $sellerInfo = $buyer->getSellerInfo($currentSellerId);
}
?>

<div class="container mt-4">
    <div class="row">
        <!-- Conversations List -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Messages</h5>
                </div>
                <div class="list-group list-group-flush">
                    <?php if (empty($conversations)): ?>
                        <div class="list-group-item text-muted">No conversations yet</div>
                    <?php else: ?>
                        <?php foreach ($conversations as $conv): ?>
                            <a href="?user=<?= $conv['seller_id'] ?>" 
                               class="list-group-item list-group-item-action <?= ($currentSellerId == $conv['seller_id']) ? 'active' : '' ?>">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h6 class="mb-1"><?= htmlspecialchars($conv['shop_name']) ?></h6>
                                    <?php if ($conv['unread_count'] > 0): ?>
                                        <span class="badge bg-primary rounded-pill"><?= $conv['unread_count'] ?></span>
                                    <?php endif; ?>
                                </div>
                                <small class="text-muted"><?= htmlspecialchars($conv['last_message']) ?></small>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Messages Area -->
        <div class="col-md-8">
            <?php if ($currentSellerId && $sellerInfo): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><?= htmlspecialchars($sellerInfo['shop_name']) ?></h5>
                    </div>
                    <div class="card-body chat-messages" id="chatMessages">
                        <?php foreach ($messages as $message): ?>
                            <div class="message <?= $message['sender_id'] == $_SESSION['user_id'] ? 'sent' : 'received' ?>">
                                <div class="message-content">
                                    <?= htmlspecialchars($message['content']) ?>
                                    <small class="message-time">
                                        <?= date('h:i A', strtotime($message['created_at'])) ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="card-footer">
                        <form id="messageForm">
                            <input type="hidden" name="receiver_id" value="<?= $currentSellerId ?>">
                            <div class="input-group">
                                <input type="text" class="form-control" name="content" placeholder="Type your message..." required>
                                <button class="btn btn-primary" type="submit">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-body text-center text-muted">
                        Select a conversation to view messages
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.chat-messages {
    height: 400px;
    overflow-y: auto;
    padding: 1rem;
}

.message {
    margin-bottom: 1rem;
    display: flex;
}

.message.sent {
    justify-content: flex-end;
}

.message-content {
    max-width: 70%;
    padding: 0.5rem 1rem;
    border-radius: 1rem;
    position: relative;
}

.message.sent .message-content {
    background-color: #007bff;
    color: white;
}

.message.received .message-content {
    background-color: #f1f1f1;
}

.message-time {
    display: block;
    font-size: 0.75rem;
    margin-top: 0.25rem;
    opacity: 0.8;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const messageForm = document.getElementById('messageForm');
    const chatMessages = document.getElementById('chatMessages');
    let messagePollingInterval;

    if (messageForm) {
        messageForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(messageForm);
            
            try {
                const response = await fetch('<?= BASE_URL ?>/api/send-message.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        receiver_id: formData.get('receiver_id'),
                        content: formData.get('content')
                    })
                });
                
                const data = await response.json();
                if (data.success) {
                    messageForm.reset();
                    loadMessages();
                }
            } catch (error) {
                console.error('Error:', error);
            }
        });

        // Start polling for new messages
        messagePollingInterval = setInterval(loadMessages, 5000);
    }

    async function loadMessages() {
        if (!chatMessages) return;
        
        try {
            const sellerId = new URLSearchParams(window.location.search).get('user');
            const response = await fetch(`<?= BASE_URL ?>/api/get-messages.php?user_id=${sellerId}`);
            const data = await response.json();
            
            if (data.success) {
                chatMessages.innerHTML = data.messages.map(msg => `
                    <div class="message ${msg.sender_id == <?= $_SESSION['user_id'] ?> ? 'sent' : 'received'}">
                        <div class="message-content">
                            ${msg.content}
                            <small class="message-time">
                                ${new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </small>
                        </div>
                    </div>
                `).join('');
                
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        } catch (error) {
            console.error('Error loading messages:', error);
        }
    }

    // Initial scroll to bottom
    if (chatMessages) {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        if (messagePollingInterval) {
            clearInterval(messagePollingInterval);
        }
    });
});
</script> 