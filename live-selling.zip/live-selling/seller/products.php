<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/seller_header.php';
require_once '../models/Seller.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$seller = new Seller();
$products = $seller->getProducts($_SESSION['user_id']);

// Handle delete action
if (isset($_POST['delete']) && isset($_POST['product_id'])) {
    if ($seller->deleteProduct($_POST['product_id'])) {
        header('Location: products.php');
        exit;
    }
}
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>My Products</h2>
        <a href="create-product.php" class="btn btn-success">Add New Product</a>
    </div>
    
    <?php if (empty($products)): ?>
        <div class="alert alert-info">No products listed yet.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?= htmlspecialchars($product['name']) ?></td>
                            <td>₱<?= number_format($product['price'], 2) ?></td>
                            <td><?= $product['quantity'] ?></td>
                            <td><?= ucfirst($product['status']) ?></td>
                            <td><?= date('M d, Y', strtotime($product['created_at'])) ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="edit-product.php?id=<?= $product['product_id'] ?>" 
                                       class="btn btn-sm btn-primary">Edit</a>
                                    <form method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this product?');">
                                        <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>">
                                        <button type="submit" name="delete" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div> 