<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/seller_header.php';
require_once '../models/Seller.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$seller = new Seller();
$profile = $seller->getProfile($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'seller_id' => $_SESSION['user_id'],
        'shop_name' => filter_input(INPUT_POST, 'shop_name', FILTER_SANITIZE_STRING),
        'description' => filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING)
    ];
    
    // Handle file upload if provided
    if (isset($_FILES['shop_image']) && $_FILES['shop_image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/shops/';
        $fileExtension = pathinfo($_FILES['shop_image']['name'], PATHINFO_EXTENSION);
        $fileName = 'shop_' . $_SESSION['user_id'] . '.' . $fileExtension;
        $uploadFile = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['shop_image']['tmp_name'], $uploadFile)) {
            $data['shop_image'] = 'uploads/shops/' . $fileName;
        }
    }
    
    if ($seller->updateProfile($data)) {
        $success = "Shop profile updated successfully";
    } else {
        $error = "Failed to update shop profile";
    }
}
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <img src="<?= BASE_URL ?>/<?= $profile['shop_image'] ?? 'assets/images/default-shop.png' ?>" 
                         class="img-fluid rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                    <h5 class="card-title"><?= htmlspecialchars($profile['shop_name']) ?></h5>
                    <p class="text-muted">Rating: <?= number_format($profile['rating'], 1) ?> ⭐</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Shop Settings</h5>
                </div>
                <div class="card-body">
                    <?php if(isset($success)): ?>
                        <div class="alert alert-success"><?= $success ?></div>
                    <?php endif; ?>
                    
                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label>Shop Name</label>
                            <input type="text" name="shop_name" class="form-control" 
                                   value="<?= htmlspecialchars($profile['shop_name']) ?>" required>
                            <small class="text-muted">This is how buyers will see your shop</small>
                        </div>
                        
                        <div class="mb-3">
                            <label>Shop Description</label>
                            <textarea name="description" class="form-control" rows="4"
                                    ><?= htmlspecialchars($profile['description']) ?></textarea>
                            <small class="text-muted">Tell buyers about your shop and what you sell</small>
                        </div>
                        
                        <div class="mb-3">
                            <label>Shop Image</label>
                            <input type="file" name="shop_image" class="form-control" accept="image/*">
                            <small class="text-muted">Recommended size: 500x500 pixels</small>
                        </div>
                        
                        <div class="mb-3">
                            <label>Contact Information</label>
                            <input type="email" class="form-control mb-2" value="<?= htmlspecialchars($_SESSION['email'] ?? '') ?>" 
                                   readonly>
                            <small class="text-muted">Email address cannot be changed here</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0">Shop Statistics</h5>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-4">
                            <h3><?= $profile['total_products'] ?? 0 ?></h3>
                            <p class="text-muted">Products</p>
                        </div>
                        <div class="col-md-4">
                            <h3><?= $profile['total_sales'] ?? 0 ?></h3>
                            <p class="text-muted">Sales</p>
                        </div>
                        <div class="col-md-4">
                            <h3><?= $profile['total_streams'] ?? 0 ?></h3>
                            <p class="text-muted">Streams</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 