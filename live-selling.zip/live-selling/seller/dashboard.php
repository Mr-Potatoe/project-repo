<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/seller_header.php';
require_once '../models/Seller.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$seller = new Seller();
$profile = $seller->getProfile($_SESSION['user_id']);
$products = $seller->getProducts($_SESSION['user_id']);
$streams = $seller->getLiveStreams($_SESSION['user_id']);
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Shop Information</h5>
                    <p class="card-text">Shop Name: <?= htmlspecialchars($profile['shop_name']) ?></p>
                    <p class="card-text">Rating: <?= number_format($profile['rating'], 1) ?> ⭐</p>
                    <a href="edit-profile.php" class="btn btn-primary">Edit Shop Profile</a>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Quick Actions</h5>
                    <a href="create-product.php" class="btn btn-success mb-2 w-100">Add New Product</a>
                    <a href="create-stream.php" class="btn btn-primary w-100">Start Live Stream</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">My Products</h5>
                    <a href="products.php" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    <?php if (empty($products)): ?>
                        <p class="text-muted">No products listed yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($products, 0, 5) as $product): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($product['name']) ?></td>
                                            <td>₱<?= number_format($product['price'], 2) ?></td>
                                            <td><?= $product['quantity'] ?></td>
                                            <td><?= ucfirst($product['status']) ?></td>
                                            <td>
                                                <a href="edit-product.php?id=<?= $product['product_id'] ?>" 
                                                   class="btn btn-sm btn-primary">Edit</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Recent Live Streams</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($streams)): ?>
                        <p class="text-muted">No streams yet.</p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach (array_slice($streams, 0, 3) as $stream): ?>
                                <div class="list-group-item">
                                    <h6 class="mb-1"><?= htmlspecialchars($stream['title']) ?></h6>
                                    <p class="mb-1 text-muted"><?= htmlspecialchars($stream['description']) ?></p>
                                    <small>
                                        Status: <?= ucfirst($stream['status']) ?> •
                                        Viewers: <?= $stream['viewer_count'] ?>
                                    </small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div> 