<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/seller_header.php';
require_once '../models/Seller.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$seller = new Seller();
$profile = $seller->getProfile($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'seller_id' => $_SESSION['user_id'],
        'shop_name' => filter_input(INPUT_POST, 'shop_name', FILTER_SANITIZE_STRING),
        'description' => filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING)
    ];
    
    if ($seller->updateProfile($data)) {
        header('Location: dashboard.php');
        exit;
    } else {
        $error = "Failed to update profile";
    }
}
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Edit Shop Profile</h5>
                </div>
                <div class="card-body">
                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label>Shop Name</label>
                            <input type="text" name="shop_name" class="form-control" 
                                   value="<?= htmlspecialchars($profile['shop_name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($profile['description']) ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Profile</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> 