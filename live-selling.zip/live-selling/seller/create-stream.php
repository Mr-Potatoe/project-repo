<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/seller_header.php';
require_once '../models/Seller.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$seller = new Seller();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'seller_id' => $_SESSION['user_id'],
        'title' => filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING),
        'description' => filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING),
        'scheduled_start' => $_POST['scheduled_start']
    ];
    
    if ($seller->createStream($data)) {
        header('Location: dashboard.php');
        exit;
    } else {
        $error = "Failed to create stream";
    }
}
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Create Live Stream</h5>
                </div>
                <div class="card-body">
                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label>Stream Title</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label>Scheduled Start Time</label>
                            <input type="datetime-local" name="scheduled_start" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Create Stream</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> 