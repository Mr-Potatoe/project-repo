<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/seller_header.php';
require_once '../models/Seller.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$seller = new Seller();
$streams = $seller->getLiveStreams($_SESSION['user_id']);
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Live Streams</h2>
        <a href="create-stream.php" class="btn btn-success">Create New Stream</a>
    </div>

    <?php if (empty($streams)): ?>
        <div class="alert alert-info">No streams scheduled yet.</div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($streams as $stream): ?>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($stream['title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($stream['description']) ?></p>
                            <div class="mb-3">
                                <small class="text-muted">
                                    Scheduled: <?= date('M d, Y h:i A', strtotime($stream['scheduled_start'])) ?><br>
                                    Status: <span class="badge bg-<?= $stream['status'] === 'live' ? 'danger' : 'secondary' ?>">
                                        <?= ucfirst($stream['status']) ?>
                                    </span>
                                </small>
                            </div>
                            <?php if ($stream['status'] === 'scheduled'): ?>
                                <button class="btn btn-primary start-stream" 
                                        data-stream-id="<?= $stream['stream_id'] ?>">
                                    Start Stream
                                </button>
                            <?php elseif ($stream['status'] === 'live'): ?>
                                <a href="broadcast.php?id=<?= $stream['stream_id'] ?>" 
                                   class="btn btn-danger">Continue Broadcasting</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const startButtons = document.querySelectorAll('.start-stream');
    startButtons.forEach(button => {
        button.addEventListener('click', function() {
            const streamId = this.dataset.streamId;
            window.location.href = `broadcast.php?id=${streamId}`;
        });
    });
});
</script> 