<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/seller_header.php';
require_once '../models/Seller.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$streamId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$seller = new Seller();
$stream = $seller->getStream($streamId);

if (!$stream || $stream['seller_id'] !== $_SESSION['user_id']) {
    header('Location: streams.php');
    exit;
}

// Update stream status to live
if ($stream['status'] === 'scheduled') {
    $seller->updateStreamStatus($streamId, 'live');
}

$products = $seller->getProducts($_SESSION['user_id']);
?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h3>Start Broadcasting</h3>
                    
                    <!-- Device Selection -->
                    <div class="mb-3">
                        <label for="videoSource" class="form-label">Camera:</label>
                        <select id="videoSource" class="form-select device-select"></select>
                    </div>
                    <div class="mb-3">
                        <label for="audioSource" class="form-label">Microphone:</label>
                        <select id="audioSource" class="form-select device-select"></select>
                    </div>

                    <!-- Error Messages -->
                    <div id="errorMessage" class="alert alert-danger" style="display: none;"></div>
                    
                    <!-- Video Preview -->
                    <div class="video-container mb-3">
                        <video id="videoPreview" playsinline autoplay muted></video>
                    </div>

                    <!-- Controls -->
                    <div class="stream-controls">
                        <button id="testDevices" class="btn btn-secondary">Test Devices</button>
                        <button id="startBroadcast" class="btn btn-primary" style="display: none;">Start Broadcasting</button>
                        <button id="stopBroadcast" class="btn btn-danger" style="display: none;">Stop Broadcasting</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Chat Section -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Live Chat</h5>
                </div>
                <div class="card-body p-0">
                    <div id="chat-messages" class="p-3" style="height: 400px; overflow-y: auto;"></div>
                    <div class="p-3 border-top">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span>Viewers: <span id="viewer-count">0</span></span>
                        </div>
                        <form id="chat-form">
                            <div class="input-group">
                                <input type="text" id="chat-input" class="form-control" placeholder="Type a message...">
                                <button type="submit" class="btn btn-primary">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/simple-peer@9.11.1/simplepeer.min.js"></script>
<script>
let localStream = null;
let ws = null;
let peers = {};
let isConnecting = false;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;
const streamId = <?= $streamId ?>;
const userId = <?= $_SESSION['user_id'] ?>;
const username = <?= json_encode($_SESSION['username']) ?>;

// Initialize WebSocket connection
async function initWebSocket() {
    if (isConnecting) return;
    isConnecting = true;

    try {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsHost = window.location.hostname;
        const wsUrl = `${wsProtocol}//${wsHost}:8080`;
        
        console.log('Connecting to WebSocket server:', wsUrl);
        ws = new WebSocket(wsUrl);
        
        ws.onopen = () => {
            console.log('Connected to WebSocket server');
            isConnecting = false;
            reconnectAttempts = 0;
            
            // Register as broadcaster
            ws.send(JSON.stringify({
                type: 'broadcaster',
                streamId: streamId,
                userId: userId,
                username: username
            }));

            // Show success message
            showMessage('Connected successfully!', 'success');
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            console.log('Received message:', data);

            switch (data.type) {
                case 'viewer_connected':
                    console.log('New viewer connected:', data.viewerId);
                    createPeerConnection(data.viewerId);
                    break;
                    
                case 'viewer_disconnected':
                    console.log('Viewer disconnected:', data.viewerId);
                    if (peers[data.viewerId]) {
                        peers[data.viewerId].destroy();
                        delete peers[data.viewerId];
                    }
                    break;
                    
                case 'signal':
                    console.log('Received signal from viewer:', data.viewerId);
                    if (peers[data.viewerId]) {
                        try {
                            peers[data.viewerId].signal(data.signal);
                        } catch (err) {
                            console.error('Error processing signal:', err);
                        }
                    }
                    break;

                case 'chat':
                    addChatMessage(data.username, data.message);
                    break;

                case 'viewer_count':
                    updateViewerCount(data.count);
                    break;

                case 'ping':
                    ws.send(JSON.stringify({ type: 'pong' }));
                    break;
            }
        };

        ws.onclose = () => {
            console.log('WebSocket connection closed');
            isConnecting = false;
            handleDisconnect();
        };

        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            isConnecting = false;
            handleDisconnect();
        };
    } catch (error) {
        console.error('Error initializing WebSocket:', error);
        isConnecting = false;
        handleDisconnect();
    }
}

// Chat functionality
function addChatMessage(username, message) {
    const chatMessages = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'mb-2';
    messageDiv.innerHTML = `
        <strong>${escapeHtml(username)}:</strong>
        <span>${escapeHtml(message)}</span>
    `;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Handle chat form submission
document.getElementById('chat-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (message && ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'chat',
            streamId: streamId,
            message: message,
            userId: userId,
            username: username
        }));
        input.value = '';
    }
});

function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function updateViewerCount(count) {
    document.getElementById('viewer-count').textContent = count;
}

function handleDisconnect() {
    isConnecting = false;
    if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        reconnectAttempts++;
        const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 10000);
        console.log(`Reconnecting in ${delay}ms (attempt ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`);
        setTimeout(initWebSocket, delay);
    } else {
        showMessage('Connection lost. Please refresh the page to try again.', 'error');
    }
}

function handleWebSocketMessage(event) {
    try {
        const data = JSON.parse(event.data);
        console.log('Received message:', data);
        
        if (data.type === 'ping') {
            ws.send(JSON.stringify({ type: 'pong' }));
            return;
        }
        
        switch(data.type) {
            case 'viewer_joined':
                console.log('New viewer joined:', data.viewerId);
                createPeerConnection(data.viewerId);
                break;
                
            case 'viewer_left':
                console.log('Viewer left:', data.viewerId);
                if (peers[data.viewerId]) {
                    peers[data.viewerId].destroy();
                    delete peers[data.viewerId];
                }
                break;
                
            case 'signal':
                console.log('Received signal from viewer:', data.viewerId);
                if (peers[data.viewerId]) {
                    try {
                        peers[data.viewerId].signal(data.signal);
                    } catch (err) {
                        console.error('Error processing signal:', err);
                    }
                }
                break;
        }
    } catch (error) {
        console.error('Error handling message:', error);
    }
}

async function testDevices() {
    const videoSelect = document.getElementById('videoSource');
    const audioSelect = document.getElementById('audioSource');
    const videoPreview = document.getElementById('videoPreview');
    const startButton = document.getElementById('startBroadcast');
    
    try {
        // Stop any existing stream
        if (localStream) {
            localStream.getTracks().forEach(track => track.stop());
        }

        // Request audio and video separately to ensure both are working
        const audioStream = await navigator.mediaDevices.getUserMedia({
            audio: {
                deviceId: audioSelect.value ? { exact: audioSelect.value } : undefined,
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true,
                channelCount: 1,
                sampleRate: 44100
            }
        });

        const videoStream = await navigator.mediaDevices.getUserMedia({
            video: {
                deviceId: videoSelect.value ? { exact: videoSelect.value } : undefined,
                width: { ideal: 854 },
                height: { ideal: 480 },
                frameRate: { ideal: 24, max: 30 }
            }
        });

        // Combine audio and video tracks
        localStream = new MediaStream([
            ...videoStream.getVideoTracks(),
            ...audioStream.getAudioTracks()
        ]);

        // Test audio levels
        const audioContext = new AudioContext();
        const source = audioContext.createMediaStreamSource(audioStream);
        const analyser = audioContext.createAnalyser();
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        source.connect(analyser);

        // Create audio meter
        const audioMeter = document.createElement('div');
        audioMeter.className = 'audio-meter mt-2';
        audioMeter.innerHTML = `
            <div class="d-flex align-items-center">
                <span class="me-2">Microphone Level:</span>
                <div class="progress" style="width: 200px; height: 20px;">
                    <div id="audio-level" class="progress-bar" role="progressbar"></div>
                </div>
            </div>
        `;
        videoPreview.parentElement.appendChild(audioMeter);

        // Update audio meter
        function updateAudioMeter() {
            analyser.getByteFrequencyData(dataArray);
            const audioLevel = dataArray.reduce((a, b) => a + b) / dataArray.length;
            const level = Math.min(100, (audioLevel / 128) * 100);
            const audioLevelEl = document.getElementById('audio-level');
            if (audioLevelEl) {
                audioLevelEl.style.width = level + '%';
                if (level < 5) {
                    audioLevelEl.className = 'progress-bar bg-danger';
                    showMessage('Warning: Low microphone volume detected', 'warning');
                } else {
                    audioLevelEl.className = 'progress-bar bg-success';
                }
            }
            requestAnimationFrame(updateAudioMeter);
        }
        updateAudioMeter();

        // Show preview
        videoPreview.srcObject = localStream;
        videoPreview.muted = true; // Mute preview to prevent feedback
        await videoPreview.play();

        // Verify tracks
        const videoTrack = localStream.getVideoTracks()[0];
        const audioTrack = localStream.getAudioTracks()[0];

        if (!videoTrack) {
            throw new Error('No video track available');
        }
        if (!audioTrack) {
            throw new Error('No audio track available');
        }

        console.log('Video track:', videoTrack.label, 'enabled:', videoTrack.enabled);
        console.log('Audio track:', audioTrack.label, 'enabled:', audioTrack.enabled);

        // Add audio controls
        const audioControls = document.createElement('div');
        audioControls.className = 'audio-controls mt-2';
        audioControls.innerHTML = `
            <div class="btn-group">
                <button id="toggle-mic" class="btn btn-primary">
                    <i class="fas fa-microphone"></i> Mute Mic
                </button>
                <input type="range" id="mic-volume" class="form-range ms-2" 
                       min="0" max="100" value="100" style="width: 100px;">
            </div>
        `;
        videoPreview.parentElement.appendChild(audioControls);

        // Add mic controls
        const toggleMic = document.getElementById('toggle-mic');
        const micVolume = document.getElementById('mic-volume');

        toggleMic.onclick = () => {
            audioTrack.enabled = !audioTrack.enabled;
            toggleMic.innerHTML = audioTrack.enabled ? 
                '<i class="fas fa-microphone"></i> Mute Mic' : 
                '<i class="fas fa-microphone-slash"></i> Unmute Mic';
        };

        micVolume.oninput = (e) => {
            const gain = audioContext.createGain();
            gain.gain.value = e.target.value / 100;
            source.connect(gain);
            gain.connect(audioContext.destination);
        };

        startButton.style.display = 'inline-block';
        showMessage('Devices connected successfully!', 'success');

    } catch (error) {
        console.error('Error testing devices:', error);
        showMessage(`Error: ${error.message}. Please check your camera and microphone permissions.`);
        startButton.style.display = 'none';
    }
}

function createPeerConnection(viewerId) {
    if (!localStream) {
        console.error('No local stream available');
        return;
    }

    try {
        // Clean up existing peer if any
        if (peers[viewerId]) {
            peers[viewerId].destroy();
            delete peers[viewerId];
        }

        console.log('Creating new peer for viewer:', viewerId);

        // Verify audio track before creating peer
        const audioTrack = localStream.getAudioTracks()[0];
        if (!audioTrack) {
            console.error('No audio track found in local stream');
            return;
        }
        console.log('Audio track found:', audioTrack.label, 'enabled:', audioTrack.enabled);

        // Create peer with audio configuration
        const peer = new SimplePeer({
            initiator: true,
            stream: localStream,
            trickle: false,
            config: {
                iceServers: [
                    { urls: 'stun:stun.l.google.com:19302' },
                    { urls: 'stun:stun.relay.metered.ca:80' },
                    { urls: 'stun:global.stun.twilio.com:3478' }
                ]
            },
            sdpTransform: (sdp) => {
                // Ensure audio is enabled in the SDP
                if (!sdp.includes('m=audio')) {
                    console.error('No audio line in SDP');
                }
                // Modify SDP to prioritize audio
                return sdp.replace(/(m=audio.*\r\n)/g, '$1b=AS:64\r\n')
                         .replace(/(m=video.*\r\n)/g, '$1b=AS:800\r\n');
            }
        });

        peers[viewerId] = peer;

        peer.on('signal', signal => {
            console.log('Generated signal for viewer:', viewerId, signal.type);
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({
                    type: 'signal',
                    viewerId: viewerId,
                    signal: signal
                }));
            }
        });

        peer.on('connect', () => {
            console.log('Peer connected:', viewerId);
            
            // Verify audio is being sent
            const audioTrack = localStream.getAudioTracks()[0];
            if (audioTrack) {
                console.log('Audio track status:', {
                    label: audioTrack.label,
                    enabled: audioTrack.enabled,
                    muted: audioTrack.muted,
                    readyState: audioTrack.readyState
                });

                // Set audio constraints
                audioTrack.applyConstraints({
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true,
                    channelCount: 1,
                    sampleRate: 44100
                }).catch(console.error);

                // Monitor audio levels
                const audioContext = new AudioContext();
                const source = audioContext.createMediaStreamSource(new MediaStream([audioTrack]));
                const analyser = audioContext.createAnalyser();
                const dataArray = new Uint8Array(analyser.frequencyBinCount);
                source.connect(analyser);

                setInterval(() => {
                    analyser.getByteFrequencyData(dataArray);
                    const audioLevel = dataArray.reduce((a, b) => a + b) / dataArray.length;
                    console.log('Outgoing audio level:', audioLevel);
                    
                    if (audioLevel < 1) {
                        console.warn('Warning: No audio being transmitted');
                    }
                }, 1000);
            } else {
                console.error('No audio track available after connection');
            }

            // Set stream bitrates
            if (peer._pc) {
                peer._pc.getSenders().forEach(sender => {
                    if (sender.track.kind === 'audio') {
                        sender.getParameters().then(params => {
                            if (!params.encodings) {
                                params.encodings = [{}];
                            }
                            params.encodings[0].maxBitrate = 64000; // 64kbps for audio
                            return sender.setParameters(params);
                        }).catch(console.error);
                    } else if (sender.track.kind === 'video') {
                        sender.getParameters().then(params => {
                            if (!params.encodings) {
                                params.encodings = [{}];
                            }
                            params.encodings[0].maxBitrate = 800000; // 800kbps for video
                            return sender.setParameters(params);
                        }).catch(console.error);
                    }
                });
            }
        });

        peer.on('error', err => {
            console.error('Peer error:', err);
            if (err.message.includes('ICE failed') || err.message.includes('Failed to set remote description')) {
                console.log('Connection failed, will attempt reconnection');
                if (peers[viewerId]) {
                    peers[viewerId].destroy();
                    delete peers[viewerId];
                    setTimeout(() => createPeerConnection(viewerId), 1000);
                }
            }
        });

        // Monitor connection quality
        if (peer._pc) {
            peer._pc.onconnectionstatechange = () => {
                const state = peer._pc.connectionState;
                console.log('Connection state:', state);
                if (state === 'failed' || state === 'disconnected') {
                    if (peers[viewerId]) {
                        peers[viewerId].destroy();
                        delete peers[viewerId];
                        setTimeout(() => createPeerConnection(viewerId), 1000);
                    }
                }
            };

            // Monitor audio track status
            setInterval(() => {
                if (peer._pc && peer._pc.getStats) {
                    peer._pc.getStats().then(stats => {
                        stats.forEach(report => {
                            if (report.type === 'outbound-rtp' && report.kind === 'audio') {
                                console.log('Audio stats:', {
                                    bytesSent: report.bytesSent,
                                    packetsSent: report.packetsSent,
                                    timestamp: report.timestamp
                                });
                            }
                        });
                    });
                }
            }, 3000);
        }

        return peer;
    } catch (error) {
        console.error('Error creating peer connection:', error);
        return null;
    }
}

// Handle browser visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Page is hidden, reduce video quality
        if (localStream) {
            localStream.getVideoTracks().forEach(track => {
                const capabilities = track.getCapabilities();
                track.applyConstraints({
                    width: { ideal: 640 },
                    height: { ideal: 360 },
                    frameRate: { ideal: 15 }
                }).catch(console.error);
            });
        }
    } else {
        // Page is visible, restore video quality
        if (localStream) {
            localStream.getVideoTracks().forEach(track => {
                track.applyConstraints({
                    width: { ideal: 854 },
                    height: { ideal: 480 },
                    frameRate: { ideal: 24 }
                }).catch(console.error);
            });
        }
    }
});

function showMessage(message, type = 'error') {
    const errorDiv = document.getElementById('errorMessage');
    errorDiv.textContent = message;
    errorDiv.className = `alert alert-${type === 'error' ? 'danger' : 'success'}`;
    errorDiv.style.display = 'block';
    
    if (type === 'success') {
        setTimeout(() => {
            errorDiv.style.display = 'none';
        }, 3000);
    }
}

// Initialize everything when the page loads
document.addEventListener('DOMContentLoaded', function() {
    initDevices();
    
    // Add event listeners
    document.getElementById('testDevices').addEventListener('click', testDevices);
    document.getElementById('startBroadcast').addEventListener('click', startBroadcast);
    document.getElementById('stopBroadcast').addEventListener('click', stopBroadcast);
    
    // Add device change listener
    navigator.mediaDevices.addEventListener('devicechange', initDevices);
});

async function initDevices() {
    try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoSelect = document.getElementById('videoSource');
        const audioSelect = document.getElementById('audioSource');
        
        videoSelect.innerHTML = '';
        audioSelect.innerHTML = '';
        
        devices.forEach(device => {
            const option = document.createElement('option');
            option.value = device.deviceId;
            option.text = device.label || (device.kind === 'videoinput' ? 'Camera ' : 'Microphone ') + (videoSelect.length + 1);
            
            if (device.kind === 'videoinput') {
                videoSelect.appendChild(option);
            } else if (device.kind === 'audioinput') {
                audioSelect.appendChild(option);
            }
        });
    } catch (error) {
        console.error('Error listing devices:', error);
        showMessage('Error accessing camera/microphone. Please make sure you\'ve granted permission to use these devices.');
    }
}

async function startBroadcast() {
    if (!localStream) {
        showMessage('Please test your devices first');
        return;
    }

    try {
        await initWebSocket();
        document.getElementById('startBroadcast').style.display = 'none';
        document.getElementById('stopBroadcast').style.display = 'inline-block';
    } catch (error) {
        console.error('Error starting broadcast:', error);
        showMessage('Failed to start broadcast. Please try again.');
    }
}

function stopBroadcast() {
    try {
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
                type: 'broadcast_ended',
                streamId: <?= $streamId ?>
            }));
            ws.close();
        }
        
        Object.values(peers).forEach(peer => peer.destroy());
        peers = {};
        
        if (localStream) {
            localStream.getTracks().forEach(track => track.stop());
            localStream = null;
        }
        
        document.getElementById('startBroadcast').style.display = 'inline-block';
        document.getElementById('stopBroadcast').style.display = 'none';
        document.getElementById('videoPreview').srcObject = null;
        
        showMessage('Broadcast ended successfully!', 'success');
    } catch (error) {
        console.error('Error stopping broadcast:', error);
        showMessage('Error stopping broadcast. Please refresh the page.');
    }
}
</script>

<style>
#videoPreview {
    width: 100%;
    max-height: 80vh;
    object-fit: contain;
    background: #000;
}

.video-container {
    position: relative;
    width: 100%;
    height: 100%;
    max-height: 80vh;
    background: #000;
}

.device-select {
    margin: 10px 0;
    width: 100%;
    max-width: 300px;
}

.stream-controls {
    margin-top: 1rem;
}

.stream-controls button {
    margin-right: 0.5rem;
}

.alert {
    margin-top: 1rem;
}
</style>