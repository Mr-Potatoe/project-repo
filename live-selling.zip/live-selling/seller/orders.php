<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/seller_header.php';
require_once '../models/Seller.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$seller = new Seller();
$reservations = $seller->getReservations($_SESSION['user_id']);
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Product Reservations</h2>
    </div>

    <?php if (empty($reservations)): ?>
        <div class="alert alert-info">No product reservations yet.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Buyer</th>
                        <th>Reserved Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reservations as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['name']) ?></td>
                            <td>₱<?= number_format($item['price'], 2) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td><?= htmlspecialchars($item['buyer_name']) ?></td>
                            <td><?= date('M d, Y', strtotime($item['created_at'])) ?></td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-primary open-chat" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#chatModal"
                                            data-buyer-id="<?= $item['reserved_by'] ?>"
                                            data-buyer-name="<?= htmlspecialchars($item['buyer_name']) ?>"
                                            data-product-id="<?= $item['product_id'] ?>"
                                            data-product-name="<?= htmlspecialchars($item['name']) ?>">
                                        Chat
                                    </button>
                                    <button type="button" class="btn btn-sm btn-success mark-sold" 
                                            data-product-id="<?= $item['product_id'] ?>">
                                        Mark as Sold
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Chat Modal -->
<div class="modal fade" id="chatModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chat with <span id="buyerName"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="card mb-3">
                    <div class="card-body">
                        <h6 class="card-title">Product Details</h6>
                        <p class="card-text" id="productDetails"></p>
                    </div>
                </div>
                <div class="chat-messages p-3" style="height: 300px; overflow-y: auto;">
                    <!-- Messages will be loaded here -->
                </div>
                <div class="chat-input mt-3">
                    <form id="messageForm" class="d-flex">
                        <input type="text" class="form-control me-2" id="messageInput" placeholder="Type your message...">
                        <button type="submit" class="btn btn-primary">Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let currentBuyerId = null;
    let currentProductId = null;
    let messagePollingInterval = null;

    // Handle opening chat modal
    const chatButtons = document.querySelectorAll('.open-chat');
    chatButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buyerId = this.dataset.buyerId;
            const buyerName = this.dataset.buyerName;
            const productId = this.dataset.productId;
            const productName = this.dataset.productName;
            
            currentBuyerId = buyerId;
            currentProductId = productId;
            
            document.getElementById('buyerName').textContent = buyerName;
            document.getElementById('productDetails').textContent = productName;
            
            loadMessages(buyerId);
            
            // Start polling for new messages
            if (messagePollingInterval) clearInterval(messagePollingInterval);
            messagePollingInterval = setInterval(() => loadMessages(buyerId), 5000);
        });
    });

    // Handle modal close
    document.getElementById('chatModal').addEventListener('hidden.bs.modal', function () {
        if (messagePollingInterval) clearInterval(messagePollingInterval);
    });

    // Handle sending messages
    document.getElementById('messageForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const input = document.getElementById('messageInput');
        const message = input.value.trim();
        
        if (!message) return;
        
        try {
            const response = await fetch('../api/send-message.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    receiver_id: currentBuyerId,
                    content: message,
                    product_id: currentProductId
                })
            });
            
            if (response.ok) {
                input.value = '';
                loadMessages(currentBuyerId);
            }
        } catch (error) {
            console.error('Error sending message:', error);
        }
    });

    async function loadMessages(buyerId) {
        try {
            const response = await fetch(`../api/get-messages.php?user_id=${buyerId}`);
            const data = await response.json();
            
            if (data.success) {
                const chatMessages = document.querySelector('.chat-messages');
                chatMessages.innerHTML = data.messages.map(msg => `
                    <div class="message ${msg.sender_id === <?= $_SESSION['user_id'] ?> ? 'text-end' : ''}">
                        <small class="text-muted">${msg.created_at}</small>
                        <div class="message-content p-2 mb-2 ${msg.sender_id === <?= $_SESSION['user_id'] ?> ? 'bg-primary text-white' : 'bg-light'} rounded">
                            ${msg.content}
                        </div>
                    </div>
                `).join('');
                
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        } catch (error) {
            console.error('Error loading messages:', error);
        }
    }

    // Handle marking product as sold
    const soldButtons = document.querySelectorAll('.mark-sold');
    soldButtons.forEach(button => {
        button.addEventListener('click', async function() {
            if (confirm('Are you sure you want to mark this product as sold?')) {
                const productId = this.dataset.productId;
                try {
                    const response = await fetch('../api/update-product-status.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            product_id: productId,
                            status: 'sold'
                        })
                    });
                    
                    if (response.ok) {
                        window.location.reload();
                    }
                } catch (error) {
                    console.error('Error updating product status:', error);
                }
            }
        });
    });
});
</script>

<style>
.chat-messages {
    background: #f8f9fa;
    border-radius: 4px;
}

.message-content {
    display: inline-block;
    max-width: 80%;
}
</style>
</rewritten_file> 