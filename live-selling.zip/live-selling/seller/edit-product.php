<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/seller_header.php';
require_once '../models/Seller.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'seller') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$seller = new Seller();
$productId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$product = $seller->getProduct($productId);

if (!$product || $product['seller_id'] !== $_SESSION['user_id']) {
    header('Location: products.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'product_id' => $productId,
        'name' => filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING),
        'description' => filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING),
        'price' => filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT),
        'quantity' => filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT),
        'status' => filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING)
    ];
    
    if ($seller->updateProduct($data)) {
        header('Location: products.php');
        exit;
    } else {
        $error = "Failed to update product";
    }
}
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Edit Product</h5>
                </div>
                <div class="card-body">
                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label>Product Name</label>
                            <input type="text" name="name" class="form-control" 
                                   value="<?= htmlspecialchars($product['name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($product['description']) ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label>Price</label>
                            <input type="number" name="price" class="form-control" step="0.01" 
                                   value="<?= $product['price'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Quantity</label>
                            <input type="number" name="quantity" class="form-control" 
                                   value="<?= $product['quantity'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Status</label>
                            <select name="status" class="form-control" required>
                                <option value="available" <?= $product['status'] === 'available' ? 'selected' : '' ?>>Available</option>
                                <option value="sold_out" <?= $product['status'] === 'sold_out' ? 'selected' : '' ?>>Sold Out</option>
                                <option value="hidden" <?= $product['status'] === 'hidden' ? 'selected' : '' ?>>Hidden</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Product</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> 