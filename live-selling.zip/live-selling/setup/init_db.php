<?php
try {
    $pdo = new PDO("mysql:host=localhost", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS live_selling");
    $pdo->exec("USE live_selling");

    // Create users table
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        user_id INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        user_type ENUM('admin', 'seller', 'buyer') NOT NULL,
        profile_picture VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");

    // Create seller_profiles table
    $pdo->exec("CREATE TABLE IF NOT EXISTS seller_profiles (
        seller_id INT PRIMARY KEY,
        shop_name VARCHAR(100) NOT NULL,
        description TEXT,
        rating DECIMAL(3,2),
        FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE
    )");

    // Create live_streams table
    $pdo->exec("CREATE TABLE IF NOT EXISTS live_streams (
        stream_id INT PRIMARY KEY AUTO_INCREMENT,
        seller_id INT,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        status ENUM('scheduled', 'live', 'ended') NOT NULL,
        scheduled_start DATETIME,
        actual_start DATETIME,
        ended_at DATETIME,
        viewer_count INT DEFAULT 0,
        FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE
    )");

    // Create products table
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        product_id INT PRIMARY KEY AUTO_INCREMENT,
        seller_id INT,
        stream_id INT,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(10,2) NOT NULL,
        quantity INT NOT NULL,
        status ENUM('available', 'sold', 'reserved') DEFAULT 'available',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE,
        FOREIGN KEY (stream_id) REFERENCES live_streams(stream_id) ON DELETE SET NULL
    )");

    // Create comments table
    $pdo->exec("CREATE TABLE IF NOT EXISTS comments (
        comment_id INT PRIMARY KEY AUTO_INCREMENT,
        stream_id INT,
        user_id INT,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (stream_id) REFERENCES live_streams(stream_id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    )");

    // Create private_messages table
    $pdo->exec("CREATE TABLE IF NOT EXISTS private_messages (
        message_id INT PRIMARY KEY AUTO_INCREMENT,
        sender_id INT,
        receiver_id INT,
        content TEXT NOT NULL,
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sender_id) REFERENCES users(user_id) ON DELETE CASCADE,
        FOREIGN KEY (receiver_id) REFERENCES users(user_id) ON DELETE CASCADE
    )");

    // Create stream_viewers table
    $pdo->exec("CREATE TABLE IF NOT EXISTS stream_viewers (
        stream_id INT,
        user_id INT,
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        left_at TIMESTAMP NULL,
        PRIMARY KEY (stream_id, user_id, joined_at),
        FOREIGN KEY (stream_id) REFERENCES live_streams(stream_id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    )");

    // Insert default admin user
    $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT IGNORE INTO users (username, password, email, user_type) 
                          VALUES (?, ?, ?, ?)");
    $stmt->execute(['admin', $adminPassword, 'admin@thrifter.com', 'admin']);

    echo "Database and tables created successfully!";
} catch(PDOException $e) {
    die("Setup failed: " . $e->getMessage());
} 